/*
Student name: Daniel Perez, Panther ID: 4566551; Student name: Miguel Cortes, Panther ID: 6065483
Week 14, Section U02

Write a program that defines and tests a class Rectangle. In the class, there 
must be methods to calculate the area, to calculate the perimeter, and to print 
the information of the rectangle. Choose appropriately the instance variable(s) 
for this real-world object and add a default constructor, a parameterized 
constructor, and a toString method.
 */

public class Lab13_03_Tester
{
    public static void main(String[] args) {
   new Lab13_03_Tester();
}
    public Lab13_03_Tester()
    {
        Rectangle r = new Rectangle();
        System.out.println(r);
    }
}